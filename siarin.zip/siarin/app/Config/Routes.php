<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Tambahan rute
$routes->get('/', 'Auth::login');
$routes->get('Auth/login', 'Auth::login');
$routes->get('/register', 'Auth::register');
$routes->post('/auth/loginAuth', 'Auth::loginAuth');
$routes->get('/auth/logout', 'Auth::logout');
$routes->get('Admin/dashboard', 'Dashboard::index');
$routes->get('/register', 'Auth::register');
$routes->post('/auth/save', 'Auth::save');

//Data User
$routes->get('usercontroller/index', 'UserController::index');
$routes->get('/users/edit/(:num)', 'UserController::edit/$1');
$routes->post('/users/update/(:num)', 'UserController::update/$1');
