<h2>Edit User</h2>
<form action="/users/update/<?= $user['id'] ?>" method="post">
    <label for="name">Name</label>
    <input type="text" name="name" value="<?= $user['name'] ?>" required>
    <label for="email">Email</label>
    <input type="email" name="email" value="<?= $user['email'] ?>" required>
    <label for="password">Password (leave blank if not changing)</label>
    <input type="password" name="password">
    <button type="submit">Update</button>
</form>