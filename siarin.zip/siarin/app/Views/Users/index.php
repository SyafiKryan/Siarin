<!DOCTYPE html>
<html>

<head>
    <title>Users List</title>
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/datepicker3.css" rel="stylesheet">
    <link href="/assets/css/styles.css" rel="stylesheet">
</head>

<body>

    <?= $this->include('layouts/topbar') ?>
    <?= $this->include('layouts/sidebar') ?>

    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#"><span class="glyphicon glyphicon-home"></span></a></li>
                <li class="active">Users</li>
            </ol>
        </div><!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Users List</h1>
            </div>
        </div><!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <a href="/users/create" class="btn btn-primary">Create New User</a>
                <div class="panel panel-default">
                    <div class="panel-heading">Users</div>
                    <div class="panel-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Username</th>
                                    <th>Role</th> <!-- Added new column for Role -->
                                    <th>Created at</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $index => $user) : ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td> <!-- Display the table row number -->
                                        <td><?= $user['username'] ?></td>
                                        <td><?= $user['role'] ?></td> <!-- Display Role -->
                                        <td><?= date('Y-m-d', strtotime($user['created_at'])) ?></td> <!-- Display only the date part of created_at -->
                                        <td>
                                            <a href="/users/edit/<?= $user['user_id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="/users/delete/<?= $user['user_id'] ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div><!--/.row-->
    </div> <!--/.main-->

    <?= $this->include('layouts/footer') ?>

</body>

</html>