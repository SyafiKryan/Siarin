<?php
$current_page = basename($_SERVER['REQUEST_URI']);
?>

<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Search">
        </div>
    </form>
    <ul class="nav menu">
        <li class="<?= $current_page == 'Admin' ? 'active' : '' ?>"><a href="/Admin/"><span class="glyphicon glyphicon-dashboard"></span> Beranda</a></li>
        <li class="parent">
            <a href="#">
                <span class="glyphicon glyphicon-folder-open"></span> Data Arsip <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span>
            </a>
            <ul class="children collapse" id="sub-item-1">
                <li class="<?= $current_page == 'Data_Surat_Produk' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Surat_Produk">
                        <span class="glyphicon glyphicon-file"></span> Surat Fire Truck
                    </a>
                </li>
                <li class="<?= $current_page == 'Data_Surat_Barang' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Surat_Barang">
                        <span class="glyphicon glyphicon-file"></span> Surat Equipment
                    </a>
                </li>
                <li class="<?= $current_page == 'Data_Surat_Jalan' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Surat_Jalan">
                        <span class="glyphicon glyphicon-file"></span> Surat Jalan
                    </a>
                </li>
                <li class="<?= $current_page == 'Data_Surat_Survey' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Surat_Survey">
                        <span class="glyphicon glyphicon-file"></span> Surat Survey Unit
                    </a>
                </li>
            </ul>
        </li>
        <li class="parent">
            <a href="#">
                <span class="glyphicon glyphicon-th-list"></span> Data Inventaris <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span>
            </a>
            <ul class="children collapse" id="sub-item-2">
                <li class="<?= $current_page == 'Data_Barang' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Barang">
                        <span class="glyphicon glyphicon-share-alt"></span> Data Barang
                    </a>
                </li>
                <li class="<?= $current_page == 'Data_Barang_Masuk' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Barang_Masuk">
                        <span class="glyphicon glyphicon-share-alt"></span> Data Barang Masuk
                    </a>
                </li>
                <li class="<?= $current_page == 'Data_Barang_Keluar' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Data_Barang_Keluar">
                        <span class="glyphicon glyphicon-share-alt"></span> Data Barang Keluar
                    </a>
                </li>
            </ul>
        </li>
        <li class="parent">
            <a href="#">
                <span class="glyphicon glyphicon-file"></span> Data Laporan <span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span>
            </a>
            <ul class="children collapse" id="sub-item-3">
                <li class="<?= $current_page == 'Laporan_Barang' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Laporan_Barang">
                        <span class="glyphicon glyphicon-share-alt"></span> Laporan Data Barang
                    </a>
                </li>
                <li class="<?= $current_page == 'Laporan_Barang_Masuk' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Laporan_Barang_Masuk">
                        <span class="glyphicon glyphicon-share-alt"></span> Laporan Barang Masuk
                    </a>
                </li>
                <li class="<?= $current_page == 'Laporan_Barang_Keluar' ? 'active' : '' ?>">
                    <a class="" href="/Admin/Laporan_Barang_Keluar">
                        <span class="glyphicon glyphicon-share-alt"></span> Laporan Barang Keluar
                    </a>
                </li>
            </ul>
        </li>
        <li class="<?= $current_page == 'index' ? 'active' : '' ?>"><a href="/usercontroller/index"><span class="glyphicon glyphicon-user"></span> Data Akun</a></li>
    </ul>
</div><!--/.sidebar-->